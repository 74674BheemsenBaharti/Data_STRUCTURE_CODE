#include<stdio.h>
#define MAXSIZE 5
int stack[MAXSIZE],top=-1;

void push()
{
    int n;
    if(top == MAXSIZE - 1)
    printf("stack is overflow\n");
    else
    {
        printf("Enter an element\n");
        scanf("%d",&n);
        top++;
        stack[top]=n;
        printf("push element is %d\n",stack[top]);
    }
}

void pop()
{
    int a;
    if(top == -1)
    printf("stack is empty\n");
    else
    {
        a=stack[top];
        top--;
        printf("popped element is %d\n",a);
    }
}

void display()
{
    int i;
    if(top == -1)
    printf("stack is empty\n");
    else
    for(i=top; i>=0; i--)
    printf("available element is %d\n",stack[i]);
}
void temp()
{
    int i;
    for(i=0; i<MAXSIZE-1; i++)
    printf("Temprory element is %d\n",stack[i]);
}

int main()
{
    int choice;
    do{
    printf("------stack------\n");
    printf("\n 1.push\n 2.pop\n 3.display\n 4.exit\n");
    printf("Enter your choice\n");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1: push();
                break;
        case 2: pop();
                break;
        case 3: display();
                break;
        case 5: temp();
                break;
        default:
        printf("Invalid choice\n");
                break;
    }//switch case
    }while(choice !=4); //do-while loop
    return 0;
}// main function