#include<stdio.h>
#include<stdlib.h>
#include"string.h"

struct node 
{
    int data;
    struct node *next;

};struct node *start=NULL,*temp,*bheem,*left,*right;

void create()
{
    int n;
    int ch;
    printf("Enter an first element\n");
    scanf("%d",&n);
    start=(struct node*)malloc (sizeof(struct node));
    start->data=n;
    start->next=NULL;
    temp=start;
    printf("-----next node addtion-------\n");
    printf("Do you want to continue(yes=1 and no=anything)\n");
    scanf("%d",&ch);
    while(ch==1)
    {
        printf("Enter next node\n");
        scanf("%d",&n);
        bheem=(struct node*)malloc(sizeof(struct node));
        bheem->data=n;
        bheem->next=NULL;
        // list connectec 1 to 2
        temp->next=bheem;
        temp=temp->next;
        printf("Do you want to continue\n");
        scanf("%d",&ch);
    }// while-loop
}// creation-funtion 

void display()
{
    if(start==NULL)
    {
        printf("list is not found\n");
    }
    else
    {
        temp=start;
        while(temp !=NULL)
        {
            printf("%d\t",temp->data);
            temp=temp->next;
        }
    }
}

void insert_first()
{
    int n;
    if(start==NULL)
    printf("List not found\n");
    else
    {
        printf("Enter an element insert_at first\n");
        scanf("%d",&n);
        bheem=(struct node*)malloc(sizeof(struct node));
        bheem->data=n;
        bheem->next=NULL;
        //connect list at first node 
        bheem->next=start;
        start=bheem;
        
    }
}

void insert_last()
{
    int n;
    if(start==NULL)
    printf("List is not found\n");
    else
    {
        printf("Enter an insert_last element\n");
        scanf("%d",&n);
        bheem=(struct node*)malloc(sizeof(struct node));
        bheem->data=n;
        bheem->next=NULL;
        temp=start;
        while(temp->next !=NULL)
        {
            temp=temp->next;
        }
        temp->next=bheem;

    }
}

void insert_middle()
{
    int n,pos,i=1;
    if(start==NULL)
    printf("List is not found\n");
    else
    {
        printf("Enter at insert_middle element\n");
        scanf("%d",&n);
        bheem=(struct node*)malloc(sizeof(struct node));
        bheem->data=n;
        bheem->next=NULL;

        printf("Enter the position\n");
        scanf("%d",&pos);
        right=start;
        while(i<pos)
        {
            left=right;
            right=right->next;
            i++;
        }
        left->next=bheem;
        bheem->next=right;
    }

}

void delete_first()
{
    if(start==NULL)
    printf("List is not found\n");
    else
    {
        temp=start;
        start=start->next;
        printf("Deleted node is %d\n",temp->data);
        free(temp);
    }
}

void delete_last()
{
    if(start==NULL)
    printf("List is not found\n");
    else
    {
        temp=start;
        while(temp->next !=NULL)
        {
            left=temp;
            temp=temp->next;
        }
        left->next=NULL;
        printf("Deleted node is %d\n",temp->data);
        free(temp);
    }
}

void delete_middle()
{
    int pos,i=1;
    if(start==NULL)
    printf("list is not found\n");
    else
    {
        printf("Enter the position\n");
        scanf("%d",&pos);
        temp=start;
        while(i<pos){
        left=temp;
    temp=temp->next;
    i++;
    right=temp->next;}
    left->next=right;
    printf("deleted node is %d\n",temp->data);
    free(temp);
    }
}

void main()
{
    int choice;
    do 
    {
    printf("\n---------Linked List creation---------\n");
    printf(" 1.create\n 2.display\n 3.insert_first\n 4.insert_last\n 5.insert_middle\n");
    printf(" 6.delete_first\n 7.delete_last\n 8.delete_middle\n 9.Exit\n");
    printf("Enter your choice\n");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1: create();
                break;
        case 2: display();
                break;
        case 3: insert_first();
                break;
        case 4: insert_last();
                break;
        case 5: insert_middle();
                break;
        case 6: delete_first();
                break;
        case 7: delete_last();
                break;
        case 8: delete_middle();
                break;
        defualt:
        printf("Invalid choice\n");
        break;
    }
    }while(choice !=9);
}
